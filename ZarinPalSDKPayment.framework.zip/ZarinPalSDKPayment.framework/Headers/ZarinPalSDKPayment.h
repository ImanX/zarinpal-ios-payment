//
//  ZarinPalSDKPayment.h
//  ZarinPalSDKPayment
//
//  Created by ImanX on 12/9/17.
//  Copyright © 2017 ImanX. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZarinPalSDKPayment.
FOUNDATION_EXPORT double ZarinPalSDKPaymentVersionNumber;

//! Project version string for ZarinPalSDKPayment.
FOUNDATION_EXPORT const unsigned char ZarinPalSDKPaymentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZarinPalSDKPayment/PublicHeader.h>


